Deprecated the ``bdist_rpm`` command. Binary packages should be built as wheels instead.
-- by :user:`hugovk`
