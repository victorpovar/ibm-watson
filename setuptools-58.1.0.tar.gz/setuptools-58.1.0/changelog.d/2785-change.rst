Replace confirparser's readfp with read_file, deprecated since Python 3.2.
-- by :user:`hugovk`
